package com.ubs.opsit.interviews;

public class BerlinClockFixtureMain implements TimeConverter{

	@Override
	public String convertTime(String aTime) {

		String strSplit[]= aTime.split(":");
		int hour= Integer.parseInt(strSplit[0]);
		int min= Integer.parseInt(strSplit[1]);
		int sec= Integer.parseInt(strSplit[2]);


		String berlinClockTime= generateBerlinClock(hour,min,sec);

		return berlinClockTime;
	}

	public String generateBerlinClock(int hour,int min,int sec) {
		StringBuffer clockBfr =new StringBuffer();
		
		int hour1=hour/5;
		int hour2=hour%5;
		int min1=min/5;
		int min2=min%5;
		
		// For lamp on the top of the clock
		if(sec%2==0) {
			clockBfr.append("Y");
		} else {
			clockBfr.append("O");
		}
		clockBfr.append(System.lineSeparator());
		
		// For first row of Hour
		for(int i=1; i<=hour1;i++) {
			clockBfr.append("R");
		}
		for(int i=hour1+1; i<=4;i++) {
			clockBfr.append("O");
		}
		clockBfr.append(System.lineSeparator());
		
		// For second row of Hour
		for(int i=1; i<=hour2;i++) {
			clockBfr.append("R");
		}
		for(int i=hour2+1; i<=4;i++) {
			clockBfr.append("O");
		}
		clockBfr.append(System.lineSeparator());
		
		
		// For first row of Minute
		for(int i=1; i<=min1;i++) {
			if(i%3==0)
				clockBfr.append("R");
			else
				clockBfr.append("Y");
		}
		for(int i=min1+1; i<=11;i++) {
			clockBfr.append("O");
		}
		clockBfr.append(System.lineSeparator());
		
		// For second row of Minute
		for(int i=1; i<=min2;i++) {
			clockBfr.append("Y");
		}
		for(int i=min2+1; i<=4;i++) {
			clockBfr.append("O");
		}
		
		
		System.out.println(clockBfr.toString());
		
		
		return clockBfr.toString();
	}
}
